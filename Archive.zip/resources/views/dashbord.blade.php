<!DOCTYPE html>


<html>
    <header>
        <title>Admin</title>
    </header>

    <body>
        <h1>Admin</h1>
    </body>
    
</html>